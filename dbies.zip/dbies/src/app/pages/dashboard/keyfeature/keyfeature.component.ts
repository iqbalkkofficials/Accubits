import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keyfeature',
  templateUrl: './keyfeature.component.html',
  styleUrls: ['./keyfeature.component.scss']
})
export class KeyfeatureComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
