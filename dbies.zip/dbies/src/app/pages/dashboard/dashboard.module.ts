import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { TopComponent } from './top/top.component';
import { KeyfeatureComponent } from './keyfeature/keyfeature.component';
import { MatCardModule } from '@angular/material/card';


@NgModule({
  declarations: [DashboardComponent, TopComponent, KeyfeatureComponent],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    MatCardModule
  ]
})
export class DashboardModule { }
